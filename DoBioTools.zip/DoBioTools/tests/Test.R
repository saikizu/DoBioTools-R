#TextTools
test = DoBioTools::FASTAreader.table("tests/example.fasta")
test = DoBioTools::FASTQreader.table("tests/example.fastq")
DoBioTools::FASTQtoFASTA.write("tests/example.fastq", "tests/example.fasta")
test = DoBioTools::FASTQtoFASTAreader.table("tests/example.fastq")
DoBioTools::TABLEtoFASTA.write(test, "tests/output.fasta", append = TRUE)
DoBioTools::TABLEtoFASTQ.write(test, "tests/output.fastq", FALSE)

#DataFrameTools
outtest =
