kmer.unique = function(dataFrame, kmer) {
  dataFrame = as.data.frame(dataFrame)
  kmer = as.integer(kmer)
  max = 4^kmer
  maxLength = max(nchar(dataFrame[,2]))
  start = as.integer(1 + kmer)
  stop = kmer + kmer
  kmerList = substr(dataFrame[,2], 1, kmer)
  while (stop <= maxLength) {
    kmerList = append(kmerList, substr(dataFrame[,2], start, stop), length(kmerList))
    kmerList = unique(kmerList)
    if (length(kmerList) >= max) {
      break
    }
    start = start + kmer
    stop = stop + kmer
  }
  return(kmerList)
}

install.packages("stringr")
kmerList=kmer.unique(dataFrame)
