#' FASTA Reader
#'
#' @description
#' Convert FASTA format to table data.
#'
#' @param fileName path of text file.
#'
#' @return data.frame.
FASTAreader.table = function(fileName)
{
  fileData = read.delim(file = fileName, sep = "", header = FALSE)
  header = fileData[seq(1, nrow(fileData), 2),]
  sequence = fileData[seq(2, nrow(fileData), 2),]
  header = sub(pattern = '>', replacement = '', x = header)
  return(data.frame("GeneID"=header,"Sequence"=sequence))
}

#' FASTQ Reader
#'
#' @description
#' Convert FASTQ format to table data.
#'
#' @param fileName path of text file
#'
#' @return data frame of FASTQ
FASTQreader.table = function(fileName)
{
  fileData = read.delim(file = fileName, sep = "", header = FALSE)
  header = fileData[seq(1, nrow(fileData), 4),]
  sequence = fileData[seq(2, nrow(fileData), 4),]
  optional = fileData[seq(3, nrow(fileData), 4),]
  score = fileData[seq(4, nrow(fileData), 4),]
  header = sub("^@", '', header)
  optional = sub("^[+]", '', optional)
  return(data.frame("GeneID"=header, "Sequence"=sequence, "Optional"=optional, "Score"=score))
}

#' FASTQ to FASTA Reader -> Table
#'
#' @description
#' Convert FASTQ to FASTA format to table data
#'
#' @param fileName path of text file.
#'
#' @return data frame of FASTA
FASTQtoFASTAreader.table = function(fileName)
{
  fasta = FASTQreader.table(fileName=fileName)
  return(fasta[,c(1,2)])
}

#' Table/Dataframe -> FASTA file
#'
#' @description
#' Write table sequences to FASTA format.
#'
#' @param table data.frame.
#' @param path path to save file.
#' @param append TRUE if you want to add your sequences to the end of file.
#'
#' @export path FASTA file.
TABLEtoFASTA.write = function(table, path, append = FALSE)
{
  table[1,1] = paste(">", table[1,1], sep = '')
  write.table(table, file = path, append = append, sep = "\n", eol = "\n>", row.names = FALSE, col.names = FALSE,
              na = "", quote = FALSE)
}

#' Table/Dataframe -> FASTQ file
#'
#' @description
#' Write table sequences to FASTQ format.
#'
#' @param table data.frame.
#' @param path path to save file.
#' @param append TRUE if you want to add your sequences to the end of file.
TABLEtoFASTQ.write = function(table, path, append = FALSE)
{
  if (ncol(table) < 4)
  {
    stop("The table is not FASTQ number of column is less than 4")
  }
  table[,1] = paste("@", table[,1], sep = '')
  table[,3] = paste("+", table[,3], sep = '')
  write.table(table, file = path, append = append, sep = "\n", eol = "\n", row.names = FALSE, col.names = FALSE,
              na = "", quote = FALSE)
}

#' FASTQ file -> FASTA file
#'
#' @description
#' Convert FASTQ to FASTA then write it to the new file
#'
#' @param FASTQinput path of the FASTQ file.
#' @param FASTAoutput path to save a FASTA file.
#' @param append TRUE if you want to add your sequences to the end of file.
FASTQtoFASTA.write = function(FASTQinput, FASTAoutput, append=FALSE)
{
  table = FASTQtoFASTAreader.table(FASTQinput)
  TABLEtoFASTA.write(table = table, path = FASTAoutput, append)
}
