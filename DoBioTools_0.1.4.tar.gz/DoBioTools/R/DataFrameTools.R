#' Rotate Column To Row With ID
#'
#' @description
#' Convert data frame from:
#' ID Rep Value       ID  1   2
#' A  1   2           A   2   3
#' A  2   3       ->  B   5   NA
#' B  1   5
#'
#' @param id index of the id column
#' @param group index of the group/column names column
#' @param value index of the value column
#'
#' @return data.frame.
TurnCollumnToRowWithID = function(dataframe, id = 1, group = 2, value = 3)
{
  require(dplyr)
  test = as.data.frame(dataframe)
  target = unique(test[[group]])
  ref = unique(test[[id]])
  ref = as.data.frame(ref)
  colnames(ref)[1] = colnames(test)[id]
  for (each in target) {
    test_add = test %>% filter(test[[group]] == each)
    colnames(test_add)[value] = each
    test_add = test_add[, !colnames(test_add) == colnames(test)[group], drop = F]
    ref = merge.data.frame(x = ref, y = test_add, by = intersect(colnames(ref), colnames(test_add)), all = TRUE, no.dups = TRUE)
  }
  return(ref)
}
