#TextTools
test = DoBioTools::FASTAreader.table("Example/example.fasta")
test = DoBioTools::FASTQreader.table("Example/example.fastq")
DoBioTools::FASTQtoFASTA.write("Example/example.fastq", "Example/example.fasta")
test = DoBioTools::FASTQtoFASTAreader.table("Example/example.fastq")
DoBioTools::TABLEtoFASTA.write(test, "Example/output.fasta", append = TRUE)
DoBioTools::TABLEtoFASTQ.write(test, "Example/output.fastq", FALSE)

#DataFrameTools
test = read.csv("Example/TableExample.csv")
output = DoBioTools::TurnCollumnToRowWithID(test)
